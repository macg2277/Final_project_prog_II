﻿Imports System.Data.SqlClient

Public Class Conexion

    Protected ccn As New SqlConnection
    Protected cmd As New SqlCommand

    Public Sub conectado()
        ccn = New SqlConnection("Data Source=DESKTOP-EG6N7VP\SQLEXPRESS;Initial Catalog=Theshop;Integrated security = true")
        ccn.Open()
    End Sub

End Class
