﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Formmenu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Formmenu))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.__________ = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.lblcantpro = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.lblcantv = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.lbltotal = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.btncreacuent = New System.Windows.Forms.Panel()
        Me.btnlistacuenta = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.lbAbout = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.__________)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Panel5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(12, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(106, 512)
        Me.Panel1.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(0, 371)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(159, 20)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "_______________"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(-2, 239)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(159, 20)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "_______________"
        '
        '__________
        '
        Me.__________.AutoSize = True
        Me.__________.Location = New System.Drawing.Point(-2, 115)
        Me.__________.Name = "__________"
        Me.__________.Size = New System.Drawing.Size(159, 20)
        Me.__________.TabIndex = 7
        Me.__________.Text = "_______________"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 475)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 29)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Ventas"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.BackgroundImage = CType(resources.GetObject("Panel5.BackgroundImage"), System.Drawing.Image)
        Me.Panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel5.Location = New System.Drawing.Point(3, 408)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(87, 64)
        Me.Panel5.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 342)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 29)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Clientes"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel4.Location = New System.Drawing.Point(3, 275)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(87, 64)
        Me.Panel4.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 213)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 29)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Productos"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(4, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 29)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Categorias"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BackgroundImage = CType(resources.GetObject("Panel3.BackgroundImage"), System.Drawing.Image)
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel3.Location = New System.Drawing.Point(3, 146)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(87, 64)
        Me.Panel3.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel2.Location = New System.Drawing.Point(3, 19)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(87, 64)
        Me.Panel2.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel6.BackgroundImage = CType(resources.GetObject("Panel6.BackgroundImage"), System.Drawing.Image)
        Me.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel6.Location = New System.Drawing.Point(23, 13)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(159, 103)
        Me.Panel6.TabIndex = 1
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel7.Controls.Add(Me.lblcantpro)
        Me.Panel7.Controls.Add(Me.Panel9)
        Me.Panel7.Controls.Add(Me.Label8)
        Me.Panel7.Location = New System.Drawing.Point(283, 52)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(534, 131)
        Me.Panel7.TabIndex = 3
        '
        'lblcantpro
        '
        Me.lblcantpro.AutoSize = True
        Me.lblcantpro.Location = New System.Drawing.Point(237, 64)
        Me.lblcantpro.Name = "lblcantpro"
        Me.lblcantpro.Size = New System.Drawing.Size(57, 20)
        Me.lblcantpro.TabIndex = 7
        Me.lblcantpro.Text = "Label9"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel9.Controls.Add(Me.Panel6)
        Me.Panel9.Location = New System.Drawing.Point(3, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(202, 125)
        Me.Panel9.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(226, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(220, 37)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "PRODUCTOS"
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.SystemColors.InfoText
        Me.Panel10.Location = New System.Drawing.Point(133, 1)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(3, 529)
        Me.Panel10.TabIndex = 5
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel8.Controls.Add(Me.lblcantv)
        Me.Panel8.Controls.Add(Me.Panel11)
        Me.Panel8.Controls.Add(Me.Label11)
        Me.Panel8.Location = New System.Drawing.Point(283, 194)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(534, 131)
        Me.Panel8.TabIndex = 6
        '
        'lblcantv
        '
        Me.lblcantv.AutoSize = True
        Me.lblcantv.Location = New System.Drawing.Point(241, 68)
        Me.lblcantv.Name = "lblcantv"
        Me.lblcantv.Size = New System.Drawing.Size(62, 20)
        Me.lblcantv.TabIndex = 7
        Me.lblcantv.Text = "lblcantv"
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel11.Controls.Add(Me.Panel12)
        Me.Panel11.Location = New System.Drawing.Point(3, 3)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(202, 125)
        Me.Panel11.TabIndex = 6
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel12.BackgroundImage = CType(resources.GetObject("Panel12.BackgroundImage"), System.Drawing.Image)
        Me.Panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel12.Location = New System.Drawing.Point(23, 13)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(159, 103)
        Me.Panel12.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(226, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(147, 37)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "VENTAS"
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel13.Controls.Add(Me.lbltotal)
        Me.Panel13.Controls.Add(Me.Panel14)
        Me.Panel13.Controls.Add(Me.Label13)
        Me.Panel13.Location = New System.Drawing.Point(286, 342)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(534, 131)
        Me.Panel13.TabIndex = 7
        '
        'lbltotal
        '
        Me.lbltotal.AutoSize = True
        Me.lbltotal.Location = New System.Drawing.Point(250, 71)
        Me.lbltotal.Name = "lbltotal"
        Me.lbltotal.Size = New System.Drawing.Size(66, 20)
        Me.lbltotal.TabIndex = 9
        Me.lbltotal.Text = "Label10"
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Panel14.Controls.Add(Me.Panel15)
        Me.Panel14.Location = New System.Drawing.Point(3, 3)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(202, 125)
        Me.Panel14.TabIndex = 6
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Panel15.BackgroundImage = CType(resources.GetObject("Panel15.BackgroundImage"), System.Drawing.Image)
        Me.Panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel15.Location = New System.Drawing.Point(23, 13)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(159, 103)
        Me.Panel15.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(226, 16)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(184, 37)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "INGRESOS"
        '
        'Panel16
        '
        Me.Panel16.BackgroundImage = CType(resources.GetObject("Panel16.BackgroundImage"), System.Drawing.Image)
        Me.Panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel16.Location = New System.Drawing.Point(854, 5)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(33, 33)
        Me.Panel16.TabIndex = 8
        '
        'Panel17
        '
        Me.Panel17.BackgroundImage = CType(resources.GetObject("Panel17.BackgroundImage"), System.Drawing.Image)
        Me.Panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel17.Location = New System.Drawing.Point(896, 5)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(33, 33)
        Me.Panel17.TabIndex = 9
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.SystemColors.InfoText
        Me.Panel18.Location = New System.Drawing.Point(0, 0)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(3, 529)
        Me.Panel18.TabIndex = 10
        '
        'btncreacuent
        '
        Me.btncreacuent.BackgroundImage = CType(resources.GetObject("btncreacuent.BackgroundImage"), System.Drawing.Image)
        Me.btncreacuent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btncreacuent.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btncreacuent.Enabled = False
        Me.btncreacuent.Location = New System.Drawing.Point(139, 387)
        Me.btncreacuent.Name = "btncreacuent"
        Me.btncreacuent.Size = New System.Drawing.Size(67, 49)
        Me.btncreacuent.TabIndex = 12
        Me.btncreacuent.Visible = False
        '
        'btnlistacuenta
        '
        Me.btnlistacuenta.BackgroundImage = CType(resources.GetObject("btnlistacuenta.BackgroundImage"), System.Drawing.Image)
        Me.btnlistacuenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnlistacuenta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnlistacuenta.Enabled = False
        Me.btnlistacuenta.Location = New System.Drawing.Point(140, 460)
        Me.btnlistacuenta.Name = "btnlistacuenta"
        Me.btnlistacuenta.Size = New System.Drawing.Size(67, 49)
        Me.btnlistacuenta.TabIndex = 13
        Me.btnlistacuenta.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label7.Location = New System.Drawing.Point(139, 513)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(138, 20)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Listado de Ventas"
        Me.Label7.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label14.Location = New System.Drawing.Point(143, 438)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 20)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Añadir venta"
        Me.Label14.Visible = False
        '
        'Panel19
        '
        Me.Panel19.BackgroundImage = CType(resources.GetObject("Panel19.BackgroundImage"), System.Drawing.Image)
        Me.Panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel19.Location = New System.Drawing.Point(864, 244)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(31, 31)
        Me.Panel19.TabIndex = 16
        '
        'lbAbout
        '
        Me.lbAbout.AutoSize = True
        Me.lbAbout.Location = New System.Drawing.Point(830, 18)
        Me.lbAbout.Name = "lbAbout"
        Me.lbAbout.Size = New System.Drawing.Size(18, 20)
        Me.lbAbout.TabIndex = 17
        Me.lbAbout.Text = "?"
        '
        'Formmenu
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(938, 529)
        Me.Controls.Add(Me.lbAbout)
        Me.Controls.Add(Me.Panel19)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.btnlistacuenta)
        Me.Controls.Add(Me.btncreacuent)
        Me.Controls.Add(Me.Panel18)
        Me.Controls.Add(Me.Panel17)
        Me.Controls.Add(Me.Panel16)
        Me.Controls.Add(Me.Panel13)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Panel10)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.HelpButton = True
        Me.MaximizeBox = False
        Me.Name = "Formmenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "e"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents __________ As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents lblcantpro As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Label11 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents btncreacuent As Panel
    Friend WithEvents btnlistacuenta As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Panel19 As Panel
    Friend WithEvents lblcantv As Label
    Friend WithEvents lbltotal As Label
    Friend WithEvents lbAbout As Label
End Class
